namespace ApiTurnos.Models
{
    public class Paciente
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Apellido { get; set; } = string.Empty;

        public ICollection<TurnoMedico>? TurnosMedicos { get; set; }
    }
}
