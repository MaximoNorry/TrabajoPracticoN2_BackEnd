using ApiTurnos.Dtos;
using ApiTurnos.Models;
using ApiTurnos.Repositorio;
using AutoMapper;

namespace ApiTurnos.Services
{
    public class TurnoMedicoService
    {
        private readonly ITurnoMedicoRepositorio _repositorio;
        private readonly IPacienteRepositorio _pacienteRepositorio; 
        private readonly IMapper _mapper;

        public TurnoMedicoService(ITurnoMedicoRepositorio repositorio, 
                                  IPacienteRepositorio pacienteRepositorio, 
                                  IMapper mapper)
        {
            _repositorio = repositorio;
            _pacienteRepositorio = pacienteRepositorio; 
            _mapper = mapper;
        }

        public async Task<IEnumerable<TurnoMedicoDto>> GetTurnosPorPacienteAsync(int pacienteId)
        {
            if (!await _pacienteRepositorio.ExistePacienteAsync(pacienteId))
            {
                return Enumerable.Empty<TurnoMedicoDto>();
            }
            var turnos = await _repositorio.GetTurnosPorPacienteAsync(pacienteId);
            return _mapper.Map<IEnumerable<TurnoMedicoDto>>(turnos);
        }

        public async Task<TurnoMedicoDto?> CrearTurnoAsync(TurnoMedicoDto dto)
        {
            if (!await _pacienteRepositorio.ExistePacienteAsync(dto.PacienteId))
            {
                return null; 
            }
            
            var turno = _mapper.Map<TurnoMedico>(dto);
            var creado = await _repositorio.CrearTurnoAsync(turno);
            return _mapper.Map<TurnoMedicoDto>(creado);
        }

        public async Task<TurnoMedicoDto?> ActualizarTurnoAsync(TurnoMedicoDto dto)
        {
            if (!await _pacienteRepositorio.ExistePacienteAsync(dto.PacienteId))
            {
                return null; 
            }

            var turno = _mapper.Map<TurnoMedico>(dto);
            var actualizado = await _repositorio.ActualizarTurnoAsync(turno);
            return actualizado == null ? null : _mapper.Map<TurnoMedicoDto>(actualizado);
        }

        public async Task<bool> EliminarTurnoAsync(int id)
        {
            return await _repositorio.EliminarTurnoAsync(id);
        }
    }
}